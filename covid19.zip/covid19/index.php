<?php include ('koneksi.php');
?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Covid-19</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="colorlib-loader"></div>

	<div id="page">
		<nav class="colorlib-nav" role="navigation">
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-md-2">
							<div id="colorlib-logo"><a href="covid19.php">Covid-19</a></div>
						</div>
						<div class="col-md-10 text-right menu-1">
							<ul>
								<li class=""><a href="covid19.php">Home</a></li>
							
							
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>

		<section id="home" class="video-hero" style="height: 700px; background-image: url(images/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<a class="player" data-property="{videoURL:'https://www.youtube.com/watch?v=vqqt5p0q-eU',containment:'#home', showControls:false, autoPlay:true, loop:true, mute:true, startAt:0, opacity:1, quality:'default'}"></a> 
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-12 col-md-offset-0">
							<div class="animate-box">
							
								<h2><i>Tetap Jaga Jarak dan Stay At Home</i></h2>
								<p>Jangan keluar rumah jika tidak ada kepentingan mendesak</p>
							
								</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<div class="colorlib-work-featured colorlib-bg-white">
			<div class="container">
				<div class="row mobile-wrap">
			           <table border="1" class="table table-bordered table-striped table-hover">
								<tr>
									<th>Nama Anda  </th><br>
									<th>Umur  </th><br>
									<th>Jenis Kelamin  </th><br>
									<th>Tujuan </th><br>
									<th>Suhu Anda  </th><br>
									<th>Keterangan</th>
									<th>Aksi</th>
								</tr>

								<?php
  								  $sql = mysqli_query($koneksi, "SELECT * FROM implode order by id ASC");
                               

								 if(mysqli_num_rows($sql)>0){?>
									<?php while($data = mysqli_fetch_array($sql)){?>
									 <tbody>

                                       

                                            <tr>
                                                <td><?php echo $data['nama'] ?></td>
                                                <td><?php echo $data['umur'] ?></td>
                                                <td><?php echo $data['jk'] ?></td>
                                                <td><?php echo $data['tujuan'] ?></td>
                                                <td><?php echo $data['suhu']."<sup>&degC</sup>" ?></td>
                                                <td><?php if ($data['suhu']<300) {
                                                	echo "Anda Bisa Lanjutkan Perjalanan";
                                                }elseif ($data['suhu']>300) {
                                                	echo "Anda Tidak Bisa Melanjutkan Perjalanan";
                                                }

                                                 ?>
                                                	
                                                </td>
                                                <td>
                                                	      <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Hapus">
                                                                <div class="button1">
                                                                     <a onclick="return confirm('Apakah Anda Yakin Akan Menghapus Data Ini ?')" href="hapus.php?id=<?php echo $data['id']; ?>">Hapus<i class=""></i></a>
                                                                </div>
                                                            </button>
                                                           
                                                </td>
                                                
                                             
                                            </tr>

                                            <?php } ?>
                                            <?php } ?>

                                                
                                            </tbody>
									
							</table>
					
		</div>
	</div>
</div>
						 

		<footer id="colorlib-footer">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-3 colorlib-widget">
						<h4>About covid19</h4>
						<p>Virus corona diases-19</p><br>
						<span>Stay At Home</span>
						<p>
							<ul class="colorlib-social-icons">
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-linkedin"></i></a></li>
								<li><a href="#"><i class="icon-dribbble"></i></a></li>
							</ul>
						</p>
					</div>
					

					<div class="col-md-3 colorlib-widget">
						<h4>Infor Kontak</h4>
						<ul class="colorlib-footer-links">
							<li>Sulawesi-Selatan, <br> Pangkep-Labakkang</li>
							<li><a href="tel://1234567920"><i class="icon-phone"></i>+685343569483</a></li>
							<li><a href="mailto:info@yoursite.com"><i class="icon-envelope"></i> nasrah.rose@gmail.com</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="copy">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center">
							<p>
								 <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> CoronavirusDiases-19<i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Ns'</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- YTPlayer -->
	<script src="js/jquery.mb.YTPlayer.min.js"></script>
	<!-- Owl carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

