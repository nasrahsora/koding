<?php
	$host       =   "localhost";
	$user       =   "root";
	$password   =   "";
	$database   =   "covid19";
	$koneksi = mysqli_connect($host, $user, $password, $database);

	if (!$koneksi){
		die("Database tidak ditemukan". mysqli_connect_error());
	}
?>