<?php 
    include 'koneksi.php';
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM implode where id='$id'");
    header("location:index.php");

 ?>